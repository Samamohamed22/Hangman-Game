from replit import clear
import random
import hangman_art
from Hangman_words import word_list 

logo=hangman_art.logo
print(logo)

chosen_word = random.choice(word_list)
print(chosen_word)

display = []

for letter in chosen_word:
    display.append("_")  # or display+="_"
                                    
end_of_game = False 
lives =  6
while not end_of_game:
    guess =input("\nGuess a letter: ").lower()
    if guess in display:
        print(f"you've already guessed{guess}letter")
    
    clear()


    for position in range (0,len(chosen_word)):
        letter = chosen_word[position] 
        if letter == guess:
            display[position]=letter
            #print(display)

    if guess not in chosen_word:
       lives=lives-1
       print("\nletter",guess,"is not in the word")
       if lives==0:
           end_of_game= True 
           print("\nyou lost The game! The man is DEAD!,the word is",chosen_word)
       print("\nyou have lost a life , you have",lives,"lives left" )

 #Join all the elements in the list and turn it into a String.
    print(f"\n{' '.join(display)}")

    if "_" not in display:
       end_of_game= True
       print("\nyou have won!")
    print( hangman_art.stages[lives])


